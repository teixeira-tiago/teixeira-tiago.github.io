package architectures.generators.topologies;

public class HOP extends MultiStage {
}
