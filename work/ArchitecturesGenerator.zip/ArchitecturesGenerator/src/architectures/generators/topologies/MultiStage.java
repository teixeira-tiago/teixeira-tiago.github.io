package architectures.generators.topologies;

import architectures.interfaces.Topology;

public class MultiStage implements Topology {

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getValue(int value, int length, int bit) {
        return 0;
    }

    @Override
    public int getValue(int value, int length) {
        return 0;
    }
}
